module.exports = {
	"13": {
		"number": 13,
		"origin": "MKE",
		"destination": "LAX",
		"departs": "10:00 AM",
		"arrives": "12:00 PM"
	},
	"18": {
		"number": 18,
		"origin": "LAX",
		"destination": "PHX",
		"departs": "9:00 AM",
		"arrives": "9:30 AM"
	},
	"33": {
		"number": 33,
		"origin": "LAX",
		"destination": "DEN",
		"departs": "5:00 PM",
		"arrives": "8:30 PM"
	}
};