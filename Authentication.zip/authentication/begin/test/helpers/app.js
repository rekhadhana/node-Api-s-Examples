var app = require('../../app'),
	flights = require('../data');

module.exports = app(flights);